<?php
$con = mysqli_connect("localhost","root","","joeloecs_bimbel");

if (mysqli_connect_error ())
{
	echo "Failed broooo" .mysqli_connect_error();
}
?>