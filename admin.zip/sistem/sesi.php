<?php 
	session_start();
		$id = $_SESSION['id'];
	$nama = $_SESSION['nama'];
?>