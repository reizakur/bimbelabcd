<?php
$con = mysqli_connect("localhost","root","","sport");

if (mysqli_connect_error ())
{
	echo "Failed broooo" .mysqli_connect_error();
}
?>
